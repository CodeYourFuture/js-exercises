# Watch some online videos

There are some really amazing videos online that explain some of the harder topics that we learnt this week.

I'd like you to search online around these topics

- Asynchronous vs Synchronous
- What is a JavaScript callback?
- Client-Server Architecture

Here are some to get started:
_Synchronous and Asynchronous Transmission_
https://www.youtube.com/watch?v=SLjjgjp2bAA

_The Client Server Model | Clients and Servers_
https://www.youtube.com/watch?v=L5BlpPU_muY

_How the Internet Works in 5 Minutes_
https://www.youtube.com/watch?v=7_LPdttKXPc

Be sure to share what you find in your class channel!
