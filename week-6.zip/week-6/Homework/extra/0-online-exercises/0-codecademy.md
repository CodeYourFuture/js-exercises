# Online Exercises

The end of this module is a really good opportunity to cover everything we've done over the last six weeks.

Codecademy has a really good course that covers a lot of what we've done.

https://www.codecademy.com/learn/introduction-to-javascript

You should complete as many or as few of these modules as you'd like from this list

1. Introduction
2. Conditionals
3. Functions
4. Scope
5. Arrays
6. Loops
7. Iterators
8. Objects
9. Classes
10. Browser Compatibility and Transpilation
