# Extra Task for Slideshow

## Optional: Add UI for delay time

Add UI so that the user can specify how long to wait between images.

## Advanced Challenge: Make it look good

Now is a good time to make it look good with CSS, colour, typography, images, and creativity. Maybe you could ask someone to collaborate with you on those aspects.
